# TP1 del curso "Codo a Codo"
Trabajo Práctico Integrador de puro Frontend hecho con HTML5, CSS3 y Bootstrap.

### Desarrollo FullStack con Java de Codo a Codo

![codoacodo](https://user-images.githubusercontent.com/83146564/137408912-013f0d0c-37d1-4dc2-a1b5-77356c1003f3.png)

### En Github Pages
https://tefsantana.github.io/tp1codoacodo/

### En Netlify
https://tp1codoacodo.netlify.app/

## Vista preliminar inicial de la página en desktop
![image](https://user-images.githubusercontent.com/83146564/137406497-dedfaa15-652a-47da-8fa3-e4980afa7552.png)

## Vista preliminar inicial de la página en mobile
![image](https://user-images.githubusercontent.com/83146564/137406688-1cdc73e5-7eec-40db-8494-cf9acee78bbf.png)

